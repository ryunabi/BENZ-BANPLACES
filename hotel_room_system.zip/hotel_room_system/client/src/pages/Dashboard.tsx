import { useEffect, useState } from "react";
import { RoomGrid } from "@/components/RoomGrid";
import { trpc } from "@/lib/trpc";
import { Room, RoomStatistics } from "@/types/hotel";
import { Loader2 } from "lucide-react";

export function DashboardPage() {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const roomsQuery = trpc.rooms.list.useQuery();
  const statsQuery = trpc.rooms.statistics.useQuery();

  const stats: RoomStatistics | null = statsQuery.data || null;

  return (
    <div className="p-6 space-y-8">
      {/* Red divider */}
      <div className="h-1 bg-accent w-full" />

      {/* Statistics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="AVAILABLE" value={stats?.available || 0} color="green" />
        <StatCard label="OCCUPIED" value={stats?.occupied || 0} color="red" />
        <StatCard label="CLEANING" value={stats?.cleaning || 0} color="yellow" />
        <StatCard label="RESERVED" value={stats?.reserved || 0} color="blue" />
      </div>

      {/* Red divider */}
      <div className="h-1 bg-accent w-full" />

      {/* Room Grid Header */}
      <div>
        <h2 className="text-3xl font-black tracking-tighter mb-6">ROOM STATUS</h2>

        {roomsQuery.isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin" size={32} />
          </div>
        ) : roomsQuery.data ? (
          <RoomGrid
            rooms={roomsQuery.data}
            onRoomClick={setSelectedRoom}
            selectedRoomId={selectedRoom?.id}
          />
        ) : null}
      </div>

      {/* Red divider */}
      <div className="h-1 bg-accent w-full" />

      {/* Selected Room Details */}
      {selectedRoom && (
        <div className="border-2 border-border p-6 bg-card">
          <h3 className="text-2xl font-black tracking-tighter mb-4">
            ROOM {selectedRoom.roomNumber}
          </h3>
          <div className="space-y-2 text-sm">
            <p>
              <span className="font-bold">STATUS:</span>{" "}
              <span className="text-accent">{selectedRoom.status.toUpperCase()}</span>
            </p>
            <p>
              <span className="font-bold">CAPACITY:</span> {selectedRoom.capacity} GUESTS
            </p>
            {selectedRoom.floor && (
              <p>
                <span className="font-bold">FLOOR:</span> {selectedRoom.floor}
              </p>
            )}
            {selectedRoom.notes && (
              <p>
                <span className="font-bold">NOTES:</span> {selectedRoom.notes}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: number;
  color: "green" | "red" | "yellow" | "blue";
}

function StatCard({ label, value, color }: StatCardProps) {
  const colorMap = {
    green: "bg-green-600",
    red: "bg-red-600",
    yellow: "bg-yellow-500",
    blue: "bg-blue-600",
  };

  return (
    <div className={`${colorMap[color]} p-6 text-white border-2 border-foreground`}>
      <div className="text-3xl font-black">{value}</div>
      <div className="text-xs font-bold mt-2 tracking-wide">{label}</div>
    </div>
  );
}
