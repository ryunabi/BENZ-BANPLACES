import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { RoomGrid } from "@/components/RoomGrid";
import { Room } from "@/types/hotel";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

type RoomStatus = "available" | "occupied" | "cleaning" | "reserved";

export function ManagementPage() {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const roomsQuery = trpc.rooms.list.useQuery();
  const updateStatusMutation = trpc.rooms.updateStatus.useMutation();
  const checkoutMutation = trpc.guests.checkout.useMutation();
  const utils = trpc.useUtils();

  const handleStatusChange = async (status: RoomStatus) => {
    if (!selectedRoom) return;

    try {
      await updateStatusMutation.mutateAsync({
        roomId: selectedRoom.id,
        status,
      });
      toast.success(`Room ${selectedRoom.roomNumber} status updated to ${status.toUpperCase()}`);
      utils.rooms.list.invalidate();
      utils.rooms.statistics.invalidate();
      setSelectedRoom(null);
    } catch (error) {
      toast.error("Failed to update room status");
    }
  };

  const handleCheckout = async () => {
    if (!selectedRoom) return;

    try {
      // Get the active guest for this room
      const guests = await utils.guests.getByRoom.fetch(selectedRoom.id);
      const activeGuest = guests.find((g) => g.status === "checked_in");

      if (!activeGuest) {
        toast.error("No active guest in this room");
        return;
      }

      await checkoutMutation.mutateAsync({
        guestId: activeGuest.id,
        roomId: selectedRoom.id,
      });
      toast.success(`Guest checked out from room ${selectedRoom.roomNumber}`);
      utils.rooms.list.invalidate();
      utils.rooms.statistics.invalidate();
      setSelectedRoom(null);
    } catch (error) {
      toast.error("Failed to check out guest");
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div className="h-1 bg-accent w-full" />

      <h1 className="text-3xl font-black tracking-tighter">ROOM STATUS MANAGEMENT</h1>

      <div className="h-1 bg-accent w-full" />

      {roomsQuery.isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin" size={32} />
        </div>
      ) : roomsQuery.data ? (
        <div>
          <h2 className="text-2xl font-black tracking-tighter mb-6">SELECT ROOM</h2>
          <RoomGrid
            rooms={roomsQuery.data}
            onRoomClick={setSelectedRoom}
            selectedRoomId={selectedRoom?.id}
          />
        </div>
      ) : null}

      <div className="h-1 bg-accent w-full" />

      {selectedRoom && (
        <div className="border-2 border-border p-6 bg-card space-y-6">
          <h3 className="text-2xl font-black tracking-tighter">ROOM {selectedRoom.roomNumber}</h3>

          <div className="space-y-2 text-sm mb-6">
            <p>
              <span className="font-bold">CURRENT STATUS:</span>{" "}
              <span className="text-accent">{selectedRoom.status.toUpperCase()}</span>
            </p>
            <p>
              <span className="font-bold">CAPACITY:</span> {selectedRoom.capacity}
            </p>
            {selectedRoom.floor && (
              <p>
                <span className="font-bold">FLOOR:</span> {selectedRoom.floor}
              </p>
            )}
          </div>

          <div className="h-1 bg-border" />

          <div className="space-y-3">
            <p className="font-bold text-sm">UPDATE STATUS TO:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatusButton
                label="AVAILABLE"
                color="green"
                onClick={() => handleStatusChange("available")}
                disabled={updateStatusMutation.isPending}
              />
              <StatusButton
                label="OCCUPIED"
                color="red"
                onClick={() => handleStatusChange("occupied")}
                disabled={updateStatusMutation.isPending}
              />
              <StatusButton
                label="CLEANING"
                color="yellow"
                onClick={() => handleStatusChange("cleaning")}
                disabled={updateStatusMutation.isPending}
              />
              <StatusButton
                label="RESERVED"
                color="blue"
                onClick={() => handleStatusChange("reserved")}
                disabled={updateStatusMutation.isPending}
              />
            </div>
          </div>

          {selectedRoom.status === "occupied" && (
            <>
              <div className="h-1 bg-border" />
              <Button
                onClick={handleCheckout}
                disabled={checkoutMutation.isPending}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-bold py-3"
              >
                {checkoutMutation.isPending && <Loader2 className="animate-spin mr-2" size={16} />}
                CHECKOUT GUEST
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

interface StatusButtonProps {
  label: string;
  color: "green" | "red" | "yellow" | "blue";
  onClick: () => void;
  disabled: boolean;
}

function StatusButton({ label, color, onClick, disabled }: StatusButtonProps) {
  const colorMap = {
    green: "bg-green-600 hover:bg-green-700",
    red: "bg-red-600 hover:bg-red-700",
    yellow: "bg-yellow-500 hover:bg-yellow-600",
    blue: "bg-blue-600 hover:bg-blue-700",
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${colorMap[color]} text-white font-bold py-3 px-4 border-2 border-foreground transition-all disabled:opacity-50`}
    >
      {label}
    </button>
  );
}
