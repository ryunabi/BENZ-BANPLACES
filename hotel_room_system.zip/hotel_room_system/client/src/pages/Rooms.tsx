import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { RoomGrid } from "@/components/RoomGrid";
import { Room } from "@/types/hotel";
import { Loader2, Plus } from "lucide-react";
import { toast } from "sonner";

export function RoomsPage() {
  const [showForm, setShowForm] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [formData, setFormData] = useState({
    roomNumber: "",
    capacity: "2",
    floor: "",
    notes: "",
  });

  const roomsQuery = trpc.rooms.list.useQuery();
  const createRoomMutation = trpc.rooms.create.useMutation();
  const deleteRoomMutation = trpc.rooms.delete.useMutation();
  const utils = trpc.useUtils();

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.roomNumber) {
      toast.error("Room number is required");
      return;
    }

    try {
      await createRoomMutation.mutateAsync({
        roomNumber: formData.roomNumber,
        capacity: parseInt(formData.capacity),
        floor: formData.floor ? parseInt(formData.floor) : undefined,
        notes: formData.notes || undefined,
      });
      toast.success(`Room ${formData.roomNumber} created`);
      setFormData({ roomNumber: "", capacity: "2", floor: "", notes: "" });
      setShowForm(false);
      utils.rooms.list.invalidate();
    } catch (error) {
      toast.error("Failed to create room");
    }
  };

  const handleDeleteRoom = async (roomId: number) => {
    if (confirm("Are you sure you want to delete this room?")) {
      try {
        await deleteRoomMutation.mutateAsync(roomId);
        toast.success("Room deleted");
        setSelectedRoom(null);
        utils.rooms.list.invalidate();
      } catch (error) {
        toast.error("Failed to delete room");
      }
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div className="h-1 bg-accent w-full" />

      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black tracking-tighter">ROOM MANAGEMENT</h1>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
        >
          <Plus size={20} />
          ADD ROOM
        </Button>
      </div>

      <div className="h-1 bg-accent w-full" />

      {showForm && (
        <form onSubmit={handleCreateRoom} className="border-2 border-border p-6 bg-card space-y-6">
          <h2 className="text-2xl font-black tracking-tighter">CREATE NEW ROOM</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold mb-2">ROOM NUMBER *</label>
              <input
                type="text"
                required
                value={formData.roomNumber}
                onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
                className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
                placeholder="e.g., 101"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">CAPACITY</label>
              <input
                type="number"
                min="1"
                value={formData.capacity}
                onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">FLOOR</label>
              <input
                type="number"
                value={formData.floor}
                onChange={(e) => setFormData({ ...formData, floor: e.target.value })}
                className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
                placeholder="e.g., 1"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">NOTES</label>
              <input
                type="text"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
                placeholder="e.g., Ocean view"
              />
            </div>
          </div>

          <div className="flex gap-4">
            <Button
              type="submit"
              disabled={createRoomMutation.isPending}
              className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
            >
              {createRoomMutation.isPending && <Loader2 className="animate-spin" size={16} />}
              CREATE ROOM
            </Button>
            <Button
              type="button"
              onClick={() => setShowForm(false)}
              variant="outline"
            >
              CANCEL
            </Button>
          </div>
        </form>
      )}

      <div className="h-1 bg-accent w-full" />

      {roomsQuery.isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin" size={32} />
        </div>
      ) : roomsQuery.data ? (
        <div>
          <h2 className="text-2xl font-black tracking-tighter mb-6">ALL ROOMS</h2>
          <RoomGrid
            rooms={roomsQuery.data}
            onRoomClick={setSelectedRoom}
            selectedRoomId={selectedRoom?.id}
          />
        </div>
      ) : null}

      {selectedRoom && (
        <div className="border-2 border-border p-6 bg-card space-y-4">
          <h3 className="text-2xl font-black tracking-tighter">ROOM {selectedRoom.roomNumber}</h3>
          <div className="space-y-2 text-sm">
            <p>
              <span className="font-bold">STATUS:</span>{" "}
              <span className="text-accent">{selectedRoom.status.toUpperCase()}</span>
            </p>
            <p>
              <span className="font-bold">CAPACITY:</span> {selectedRoom.capacity}
            </p>
            {selectedRoom.floor && (
              <p>
                <span className="font-bold">FLOOR:</span> {selectedRoom.floor}
              </p>
            )}
            {selectedRoom.notes && (
              <p>
                <span className="font-bold">NOTES:</span> {selectedRoom.notes}
              </p>
            )}
          </div>
          <Button
            onClick={() => handleDeleteRoom(selectedRoom.id)}
            variant="destructive"
            disabled={deleteRoomMutation.isPending}
          >
            DELETE ROOM
          </Button>
        </div>
      )}
    </div>
  );
}
