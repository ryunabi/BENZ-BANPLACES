import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { HotelDashboard } from "@/components/HotelDashboard";
import { DashboardPage } from "./Dashboard";
import { RoomsPage } from "./Rooms";
import { GuestsPage } from "./Guests";
import { ActivityLogPage } from "./ActivityLog";
import { ManagementPage } from "./Management";
import { NotificationsPage } from "./Notifications";
import { ReportsPage } from "./Reports";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [currentPage, setCurrentPage] = useState("dashboard");

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-6xl font-black mb-4">LOADING...</h1>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-6">
        <div className="h-1 bg-accent w-full absolute top-0 left-0" />
        <div className="text-center space-y-8 max-w-2xl">
          <h1 className="text-6xl font-black tracking-tighter">BENZ-BAN</h1>
          <h1 className="text-6xl font-black tracking-tighter">PLACE</h1>
          <div className="h-1 bg-accent w-full" />
          <p className="text-lg font-semibold text-muted-foreground">
            REAL-TIME ROOM AVAILABILITY TRACKING FOR FRONT DESK STAFF
          </p>
          <div className="h-1 bg-accent w-full" />
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            size="lg"
            className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold text-lg px-8 py-6"
          >
            LOGIN TO SYSTEM
          </Button>
        </div>
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DashboardPage />;
      case "rooms":
        return <RoomsPage />;
      case "guests":
        return <GuestsPage />;
      case "activity":
        return <ActivityLogPage />;
      case "management":
        return <ManagementPage />;
      case "notifications":
        return <NotificationsPage />;
      case "reports":
        return <ReportsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <HotelDashboard currentPage={currentPage} onNavigate={setCurrentPage}>
      {renderPage()}
    </HotelDashboard>
  );
}
