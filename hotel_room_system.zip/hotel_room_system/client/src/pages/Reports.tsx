import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, Download } from "lucide-react";
import { toast } from "sonner";

export function ReportsPage() {
  const [exportFormat, setExportFormat] = useState<"csv" | "pdf">("csv");
  const roomsQuery = trpc.rooms.list.useQuery();
  const activityQuery = trpc.activityLog.list.useQuery(200);

  const handleExportGuests = async () => {
    try {
      const rooms = roomsQuery.data || [];
      const occupied = rooms.filter((r) => r.status === "occupied");

      if (occupied.length === 0) {
        toast.error("No occupied rooms to export");
        return;
      }

      let content = "";

      if (exportFormat === "csv") {
        content = "Room Number,Guest Name,Email,Phone,Check-In Date\n";
        occupied.forEach((room) => {
          content += `${room.roomNumber},N/A,N/A,N/A,N/A\n`;
        });
      } else {
        content = "GUEST CHECK-IN REPORT\n\n";
        content += `Generated: ${new Date().toLocaleString()}\n\n`;
        occupied.forEach((room) => {
          content += `Room ${room.roomNumber}: N/A\n`;
        });
      }

      downloadFile(content, `guest-report.${exportFormat}`);
      toast.success(`Report exported as ${exportFormat.toUpperCase()}`);
    } catch (error) {
      toast.error("Failed to export report");
    }
  };

  const handleExportOccupancy = async () => {
    try {
      const rooms = roomsQuery.data || [];
      const stats = {
        available: rooms.filter((r) => r.status === "available").length,
        occupied: rooms.filter((r) => r.status === "occupied").length,
        cleaning: rooms.filter((r) => r.status === "cleaning").length,
        reserved: rooms.filter((r) => r.status === "reserved").length,
        total: rooms.length,
      };

      let content = "";

      if (exportFormat === "csv") {
        content = "Status,Count,Percentage\n";
        content += `Available,${stats.available},${((stats.available / stats.total) * 100).toFixed(1)}%\n`;
        content += `Occupied,${stats.occupied},${((stats.occupied / stats.total) * 100).toFixed(1)}%\n`;
        content += `Cleaning,${stats.cleaning},${((stats.cleaning / stats.total) * 100).toFixed(1)}%\n`;
        content += `Reserved,${stats.reserved},${((stats.reserved / stats.total) * 100).toFixed(1)}%\n`;
      } else {
        content = "OCCUPANCY REPORT\n\n";
        content += `Generated: ${new Date().toLocaleString()}\n\n`;
        content += `Available: ${stats.available} (${((stats.available / stats.total) * 100).toFixed(1)}%)\n`;
        content += `Occupied: ${stats.occupied} (${((stats.occupied / stats.total) * 100).toFixed(1)}%)\n`;
        content += `Cleaning: ${stats.cleaning} (${((stats.cleaning / stats.total) * 100).toFixed(1)}%)\n`;
        content += `Reserved: ${stats.reserved} (${((stats.reserved / stats.total) * 100).toFixed(1)}%)\n`;
        content += `Total Rooms: ${stats.total}\n`;
      }

      downloadFile(content, `occupancy-report.${exportFormat}`);
      toast.success(`Report exported as ${exportFormat.toUpperCase()}`);
    } catch (error) {
      toast.error("Failed to export report");
    }
  };

  const handleExportActivity = async () => {
    try {
      const logs = activityQuery.data || [];

      let content = "";

      if (exportFormat === "csv") {
        content = "Room,Action,Previous Status,New Status,Timestamp\n";
        logs.forEach((log) => {
          content += `${log.roomId},${log.action},${log.previousStatus || "N/A"},${log.newStatus},${new Date(log.createdAt).toLocaleString()}\n`;
        });
      } else {
        content = "ACTIVITY LOG REPORT\n\n";
        content += `Generated: ${new Date().toLocaleString()}\n\n`;
        logs.forEach((log) => {
          content += `[${new Date(log.createdAt).toLocaleString()}] Room ${log.roomId}: ${log.action.toUpperCase()} (${log.previousStatus || "N/A"} → ${log.newStatus})\n`;
        });
      }

      downloadFile(content, `activity-report.${exportFormat}`);
      toast.success(`Report exported as ${exportFormat.toUpperCase()}`);
    } catch (error) {
      toast.error("Failed to export report");
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div className="h-1 bg-accent w-full" />

      <h1 className="text-3xl font-black tracking-tighter">REPORTS & EXPORT</h1>

      <div className="h-1 bg-accent w-full" />

      <div className="border-2 border-border p-6 bg-card space-y-4">
        <h2 className="text-xl font-black tracking-tighter">EXPORT FORMAT</h2>
        <div className="flex gap-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              value="csv"
              checked={exportFormat === "csv"}
              onChange={(e) => setExportFormat(e.target.value as "csv" | "pdf")}
              className="w-4 h-4"
            />
            <span className="font-semibold">CSV</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              value="pdf"
              checked={exportFormat === "pdf"}
              onChange={(e) => setExportFormat(e.target.value as "csv" | "pdf")}
              className="w-4 h-4"
            />
            <span className="font-semibold">TEXT (PDF-ready)</span>
          </label>
        </div>
      </div>

      <div className="h-1 bg-accent w-full" />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <ReportCard
          title="GUEST CHECK-IN HISTORY"
          description="Export all current guest check-ins"
          onClick={handleExportGuests}
          isLoading={roomsQuery.isLoading}
        />
        <ReportCard
          title="OCCUPANCY REPORT"
          description="Export current room occupancy statistics"
          onClick={handleExportOccupancy}
          isLoading={roomsQuery.isLoading}
        />
        <ReportCard
          title="ACTIVITY LOG"
          description="Export recent room status changes"
          onClick={handleExportActivity}
          isLoading={activityQuery.isLoading}
        />
      </div>

      <div className="h-1 bg-accent w-full" />

      <div className="border-2 border-border p-6 bg-card space-y-4">
        <h2 className="text-xl font-black tracking-tighter">EXPORT INFORMATION</h2>
        <ul className="space-y-2 text-sm">
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>CSV files can be opened in Excel, Google Sheets, or any spreadsheet application</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>TEXT files are formatted for PDF conversion and printing</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>All reports include timestamps and current data at time of export</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>Reports are automatically downloaded to your default download folder</span>
          </li>
        </ul>
      </div>
    </div>
  );
}

interface ReportCardProps {
  title: string;
  description: string;
  onClick: () => void;
  isLoading: boolean;
}

function ReportCard({ title, description, onClick, isLoading }: ReportCardProps) {
  return (
    <div className="border-2 border-border p-6 bg-card space-y-4 flex flex-col">
      <h3 className="font-black text-lg tracking-tighter">{title}</h3>
      <p className="text-sm text-muted-foreground flex-1">{description}</p>
      <Button
        onClick={onClick}
        disabled={isLoading}
        className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center justify-center gap-2 w-full"
      >
        {isLoading ? (
          <Loader2 className="animate-spin" size={16} />
        ) : (
          <Download size={16} />
        )}
        EXPORT
      </Button>
    </div>
  );
}

function downloadFile(content: string, filename: string) {
  const element = document.createElement("a");
  element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(content));
  element.setAttribute("download", filename);
  element.style.display = "none";
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
}
