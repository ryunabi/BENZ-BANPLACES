import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Room } from "@/types/hotel";
import { Loader2, Plus } from "lucide-react";
import { toast } from "sonner";

export function GuestsPage() {
  const [showForm, setShowForm] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [formData, setFormData] = useState({ 
    name: "", 
    email: "", 
    phone: "", 
    guestCount: "1",
    checkInDate: new Date().toISOString().split('T')[0],
    checkOutDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    extraBed: "0"
  });

  const roomsQuery = trpc.rooms.list.useQuery();
  const createGuestMutation = trpc.guests.create.useMutation();
  const utils = trpc.useUtils();

  const availableRooms = roomsQuery.data?.filter((r) => r.status === "available") || [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRoom || !formData.name) {
      toast.error("Please select a room and enter guest name");
      return;
    }

    try {
      await createGuestMutation.mutateAsync({
        roomId: selectedRoom.id,
        name: formData.name,
        email: formData.email || undefined,
        phone: formData.phone || undefined,
        guestCount: parseInt(formData.guestCount),
        extraBed: parseInt(formData.extraBed),
        checkInDate: new Date(formData.checkInDate),
        checkOutDate: new Date(formData.checkOutDate),
      });
      toast.success(`Guest ${formData.name} checked in to room ${selectedRoom.roomNumber}`);
      setFormData({ 
        name: "", 
        email: "", 
        phone: "", 
        guestCount: "1",
        checkInDate: new Date().toISOString().split('T')[0],
        checkOutDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
        extraBed: "0"
      });
      setSelectedRoom(null);
      setShowForm(false);
      utils.rooms.list.invalidate();
    } catch (error) {
      toast.error("Failed to check in guest");
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div className="h-1 bg-accent w-full" />

      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black tracking-tighter">WALK-IN GUEST CHECK-IN</h1>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
        >
          <Plus size={20} />
          NEW CHECK-IN
        </Button>
      </div>

      <div className="h-1 bg-accent w-full" />

      {showForm && (
        <form onSubmit={handleSubmit} className="border-2 border-border p-6 bg-card space-y-6">
          <h2 className="text-2xl font-black tracking-tighter">GUEST REGISTRATION</h2>

          <div>
            <label className="block text-sm font-bold mb-2">GUEST NAME *</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
              placeholder="Enter full name"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">EMAIL</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
              placeholder="Enter email (optional)"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">PHONE</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
              placeholder="Enter phone (optional)"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">GUEST COUNT *</label>
            <input
              type="number"
              min="1"
              max="10"
              required
              value={formData.guestCount}
              onChange={(e) => setFormData({ ...formData, guestCount: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
              placeholder="Enter number of guests"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">CHECK-IN DATE *</label>
            <input
              type="date"
              required
              value={formData.checkInDate}
              onChange={(e) => setFormData({ ...formData, checkInDate: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">CHECK-OUT DATE *</label>
            <input
              type="date"
              required
              value={formData.checkOutDate}
              onChange={(e) => setFormData({ ...formData, checkOutDate: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">EXTRA BED</label>
            <input
              type="number"
              min="0"
              max="5"
              value={formData.extraBed}
              onChange={(e) => setFormData({ ...formData, extraBed: e.target.value })}
              className="w-full px-4 py-2 bg-background border-2 border-border text-foreground font-semibold"
              placeholder="Enter number of extra beds (optional)"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2">SELECT ROOM *</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {availableRooms.map((room) => (
                <button
                  key={room.id}
                  type="button"
                  onClick={() => setSelectedRoom(room)}
                  className={`p-4 border-2 font-bold text-center transition-all ${
                    selectedRoom?.id === room.id
                      ? "border-accent bg-background"
                      : "border-border hover:border-accent"
                  }`}
                >
                  <div className="text-xl font-black">{room.roomNumber}</div>
                  <div className="text-xs mt-1">AVAILABLE</div>
                </button>
              ))}
            </div>
            {availableRooms.length === 0 && (
              <p className="text-muted-foreground mt-2">No available rooms</p>
            )}
          </div>

          <div className="flex gap-4">
            <Button
              type="submit"
              disabled={createGuestMutation.isPending}
              className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
            >
              {createGuestMutation.isPending && <Loader2 className="animate-spin" size={16} />}
              CHECK IN GUEST
            </Button>
            <Button
              type="button"
              onClick={() => setShowForm(false)}
              variant="outline"
            >
              CANCEL
            </Button>
          </div>
        </form>
      )}

      <div className="h-1 bg-accent w-full" />

      <div className="text-center py-12 text-muted-foreground">
        <p className="text-lg font-semibold">Click "NEW CHECK-IN" to register a walk-in guest</p>
      </div>
    </div>
  );
}
