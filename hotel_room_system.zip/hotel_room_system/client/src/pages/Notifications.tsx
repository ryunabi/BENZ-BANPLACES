import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, Check } from "lucide-react";
import { toast } from "sonner";

export function NotificationsPage() {
  const notificationsQuery = trpc.notifications.list.useQuery();
  const markAsReadMutation = trpc.notifications.markAsRead.useMutation();
  const utils = trpc.useUtils();

  const handleMarkAsRead = async (id: number) => {
    try {
      await markAsReadMutation.mutateAsync(id);
      utils.notifications.list.invalidate();
      toast.success("Notification marked as read");
    } catch (error) {
      toast.error("Failed to mark notification as read");
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "all_occupied":
        return "bg-red-600";
      case "cleaning_backlog":
        return "bg-yellow-500";
      case "status_change":
        return "bg-blue-600";
      default:
        return "bg-gray-600";
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div className="h-1 bg-accent w-full" />

      <h1 className="text-3xl font-black tracking-tighter">NOTIFICATIONS</h1>

      <div className="h-1 bg-accent w-full" />

      {notificationsQuery.isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin" size={32} />
        </div>
      ) : notificationsQuery.data && notificationsQuery.data.length > 0 ? (
        <div className="space-y-4">
          {notificationsQuery.data.map((notification) => (
            <div
              key={notification.id}
              className="border-2 border-border p-4 bg-card flex items-start gap-4"
            >
              <div
                className={`${getTypeColor(notification.type)} text-white px-4 py-2 font-bold text-sm min-w-fit`}
              >
                {notification.type.toUpperCase().replace(/_/g, " ")}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">{notification.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{notification.content}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  {new Date(notification.createdAt).toLocaleString()}
                </p>
              </div>
              <Button
                onClick={() => handleMarkAsRead(notification.id)}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                <Check size={16} />
                MARK READ
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <p className="text-lg font-semibold">No unread notifications</p>
        </div>
      )}

      <div className="h-1 bg-accent w-full" />

      <div className="border-2 border-border p-6 bg-card space-y-4">
        <h2 className="text-xl font-black tracking-tighter">NOTIFICATION TRIGGERS</h2>
        <ul className="space-y-2 text-sm">
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>
              <span className="font-bold">ALL OCCUPIED:</span> Triggered when all rooms are occupied
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>
              <span className="font-bold">CLEANING BACKLOG:</span> Triggered when 5 or more rooms
              need cleaning
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent font-bold">•</span>
            <span>
              <span className="font-bold">STATUS CHANGE:</span> Triggered on critical room status
              changes
            </span>
          </li>
        </ul>
      </div>
    </div>
  );
}
