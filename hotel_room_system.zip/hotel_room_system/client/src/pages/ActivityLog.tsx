import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { ActivityLog as ActivityLogType } from "@/types/hotel";
import { Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ActivityLogPage() {
  const [limit, setLimit] = useState(50);
  const activityQuery = trpc.activityLog.list.useQuery(limit);
  const utils = trpc.useUtils();

  const handleRefresh = () => {
    utils.activityLog.list.invalidate();
  };

  const getActionLabel = (action: string) => {
    switch (action) {
      case "check_in":
        return "CHECK-IN";
      case "check_out":
        return "CHECK-OUT";
      case "status_change":
        return "STATUS CHANGE";
      default:
        return action.toUpperCase();
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleString();
  };

  return (
    <div className="p-6 space-y-8">
      <div className="h-1 bg-accent w-full" />

      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black tracking-tighter">ACTIVITY LOG</h1>
        <Button
          onClick={handleRefresh}
          variant="outline"
          className="flex items-center gap-2"
        >
          <RefreshCw size={16} />
          REFRESH
        </Button>
      </div>

      <div className="h-1 bg-accent w-full" />

      {activityQuery.isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin" size={32} />
        </div>
      ) : activityQuery.data && activityQuery.data.length > 0 ? (
        <div className="space-y-4">
          {activityQuery.data.map((log) => (
            <ActivityLogEntry key={log.id} log={log} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <p className="text-lg font-semibold">No activity recorded yet</p>
        </div>
      )}

      <div className="h-1 bg-accent w-full" />

      <div className="flex justify-center gap-4">
        <Button
          onClick={() => setLimit(50)}
          variant={limit === 50 ? "default" : "outline"}
        >
          LAST 50
        </Button>
        <Button
          onClick={() => setLimit(100)}
          variant={limit === 100 ? "default" : "outline"}
        >
          LAST 100
        </Button>
        <Button
          onClick={() => setLimit(200)}
          variant={limit === 200 ? "default" : "outline"}
        >
          LAST 200
        </Button>
      </div>
    </div>
  );
}

interface ActivityLogEntryProps {
  log: ActivityLogType;
}

function ActivityLogEntry({ log }: ActivityLogEntryProps) {
  const getActionColor = (action: string) => {
    switch (action) {
      case "check_in":
        return "bg-green-600";
      case "check_out":
        return "bg-yellow-500";
      case "status_change":
        return "bg-blue-600";
      default:
        return "bg-gray-600";
    }
  };

  return (
    <div className="border-2 border-border p-4 bg-card flex items-start gap-4">
      <div className={`${getActionColor(log.action)} text-white px-4 py-2 font-bold text-sm min-w-fit`}>
        {log.action.toUpperCase().replace(/_/g, " ")}
      </div>
      <div className="flex-1 space-y-1">
        <div className="font-bold">
          ROOM {log.roomId}
          {log.previousStatus && log.newStatus && (
            <span className="text-muted-foreground font-normal text-sm">
              {" "}
              • {log.previousStatus.toUpperCase()} → {log.newStatus.toUpperCase()}
            </span>
          )}
        </div>
        {log.notes && <p className="text-sm text-muted-foreground">{log.notes}</p>}
        <p className="text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString()}</p>
      </div>
    </div>
  );
}
