export interface Room {
  id: number;
  roomNumber: string;
  status: "available" | "occupied" | "cleaning" | "reserved";
  capacity: number;
  floor: number | null;
  notes: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Guest {
  id: number;
  roomId: number;
  name: string;
  email: string | null;
  phone: string | null;
  checkInDate: Date;
  checkOutDate: Date | null;
  status: "checked_in" | "checked_out";
  createdAt: Date;
  updatedAt: Date;
}

export interface ActivityLog {
  id: number;
  roomId: number;
  guestId: number | null;
  action: string;
  previousStatus: string | null;
  newStatus: string;
  notes: string | null;
  userId: number;
  createdAt: Date;
}

export interface Notification {
  id: number;
  title: string;
  content: string;
  type: "all_occupied" | "cleaning_backlog" | "status_change";
  isRead: number;
  createdAt: Date;
}

export interface RoomStatistics {
  available: number;
  occupied: number;
  cleaning: number;
  reserved: number;
  total: number;
}
