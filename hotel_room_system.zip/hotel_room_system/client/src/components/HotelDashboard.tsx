import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { LogOut, Menu, X } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface DashboardProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function HotelDashboard({ children, currentPage, onNavigate }: DashboardProps) {
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Red divider line */}
      <div className="h-1 bg-accent w-full" />

      {/* Header */}
      <header className="border-b border-border px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-card"
          >
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          <h1 className="text-4xl font-black tracking-tighter">BENZ-BAN PLACE</h1>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm font-semibold">{user?.name}</span>
          <Button
            onClick={handleLogout}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <LogOut size={16} />
            LOGOUT
          </Button>
        </div>
      </header>

      {/* Red divider line */}
      <div className="h-1 bg-accent w-full" />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="w-64 border-r border-border bg-card overflow-y-auto">
            <nav className="p-6 space-y-4">
              <NavItem
                label="DASHBOARD"
                active={currentPage === "dashboard"}
                onClick={() => onNavigate("dashboard")}
              />
              <NavItem
                label="ROOMS"
                active={currentPage === "rooms"}
                onClick={() => onNavigate("rooms")}
              />
              <NavItem
                label="GUESTS"
                active={currentPage === "guests"}
                onClick={() => onNavigate("guests")}
              />
              <NavItem
                label="ACTIVITY LOG"
                active={currentPage === "activity"}
                onClick={() => onNavigate("activity")}
              />
              <NavItem
                label="MANAGEMENT"
                active={currentPage === "management"}
                onClick={() => onNavigate("management")}
              />
              <NavItem
                label="NOTIFICATIONS"
                active={currentPage === "notifications"}
                onClick={() => onNavigate("notifications")}
              />
              <NavItem
                label="REPORTS"
                active={currentPage === "reports"}
                onClick={() => onNavigate("reports")}
              />
            </nav>
          </aside>
        )}

        {/* Main content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

interface NavItemProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

function NavItem({ label, active, onClick }: NavItemProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-3 font-bold text-sm tracking-wide border-l-4 transition-colors ${
        active
          ? "border-accent bg-background text-foreground"
          : "border-transparent text-muted-foreground hover:bg-background"
      }`}
    >
      {label}
    </button>
  );
}
