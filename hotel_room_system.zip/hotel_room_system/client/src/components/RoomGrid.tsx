import { Room } from "@/types/hotel";

interface RoomGridProps {
  rooms: Room[];
  onRoomClick?: (room: Room) => void;
  selectedRoomId?: number;
}

export function RoomGrid({ rooms, onRoomClick, selectedRoomId }: RoomGridProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-600 text-white";
      case "occupied":
        return "bg-red-600 text-white";
      case "cleaning":
        return "bg-yellow-500 text-black";
      case "reserved":
        return "bg-blue-600 text-white";
      default:
        return "bg-gray-600 text-white";
    }
  };

  const getStatusLabel = (status: string) => {
    return status.toUpperCase().replace(/_/g, " ");
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 p-6">
      {rooms.map((room) => (
        <button
          key={room.id}
          onClick={() => onRoomClick?.(room)}
          className={`aspect-square flex flex-col items-center justify-center border-2 transition-all font-bold text-sm ${
            selectedRoomId === room.id
              ? "border-accent scale-105"
              : "border-border hover:border-accent"
          } ${getStatusColor(room.status)}`}
        >
          <div className="text-2xl font-black">{room.roomNumber}</div>
          <div className="text-xs mt-2 opacity-90">{getStatusLabel(room.status)}</div>
        </button>
      ))}
    </div>
  );
}
