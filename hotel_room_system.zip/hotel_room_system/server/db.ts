import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, rooms, guests, activityLog, notifications, Room, Guest, ActivityLog, Notification, InsertRoom, InsertGuest, InsertActivityLog, InsertNotification } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Room queries
export async function getAllRooms(): Promise<Room[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rooms).execute();
}

export async function getRoomById(id: number): Promise<Room | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(rooms).where(eq(rooms.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createRoom(data: InsertRoom): Promise<Room> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(rooms).values(data);
  const result = await db.select().from(rooms).where(eq(rooms.roomNumber, data.roomNumber)).limit(1);
  return result[0];
}

export async function updateRoomStatus(roomId: number, status: "available" | "occupied" | "cleaning" | "reserved"): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(rooms).set({ status, updatedAt: new Date() }).where(eq(rooms.id, roomId));
}

export async function deleteRoom(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // First delete related records
  await db.delete(activityLog).where(eq(activityLog.roomId, id));
  await db.delete(guests).where(eq(guests.roomId, id));
  await db.delete(rooms).where(eq(rooms.id, id));
}

// Guest queries
export async function getGuestsByRoom(roomId: number): Promise<Guest[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(guests).where(eq(guests.roomId, roomId)).execute();
}

export async function getActiveGuestInRoom(roomId: number): Promise<Guest | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(guests).where(and(eq(guests.roomId, roomId), eq(guests.status, "checked_in"))).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createGuest(data: InsertGuest): Promise<Guest> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(guests).values(data);
  const result = await db.select().from(guests).where(eq(guests.roomId, data.roomId)).orderBy(guests.id).limit(1);
  return result[0];
}

export async function checkOutGuest(guestId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(guests).set({ status: "checked_out", checkOutDate: new Date() }).where(eq(guests.id, guestId));
}

// Activity log queries
export async function getActivityLog(limit: number = 50): Promise<ActivityLog[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityLog).orderBy(activityLog.createdAt).limit(limit).execute();
}

export async function createActivityLogEntry(data: InsertActivityLog): Promise<ActivityLog> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(activityLog).values(data);
  const result = await db.select().from(activityLog).orderBy(activityLog.id).limit(1);
  return result[0];
}

// Notification queries
export async function createNotification(data: InsertNotification): Promise<Notification> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(notifications).values(data);
  const result = await db.select().from(notifications).orderBy(notifications.id).limit(1);
  return result[0];
}

export async function getUnreadNotifications(): Promise<Notification[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.isRead, 0)).execute();
}

export async function markNotificationAsRead(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notifications).set({ isRead: 1 }).where(eq(notifications.id, id));
}

export async function getRoomStatistics() {
  const db = await getDb();
  if (!db) return { available: 0, occupied: 0, cleaning: 0, reserved: 0, total: 0 };
  
  const allRooms = await db.select().from(rooms).execute();
  const stats = {
    available: allRooms.filter(r => r.status === "available").length,
    occupied: allRooms.filter(r => r.status === "occupied").length,
    cleaning: allRooms.filter(r => r.status === "cleaning").length,
    reserved: allRooms.filter(r => r.status === "reserved").length,
    total: allRooms.length,
  };
  return stats;
}
