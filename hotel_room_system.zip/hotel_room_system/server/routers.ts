import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getAllRooms,
  getRoomById,
  createRoom,
  updateRoomStatus,
  deleteRoom,
  getRoomStatistics,
  getGuestsByRoom,
  createGuest,
  checkOutGuest,
  getActivityLog,
  getUnreadNotifications,
  markNotificationAsRead,
  createActivityLogEntry,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  rooms: router({
    list: publicProcedure.query(async () => {
      return getAllRooms();
    }),
    getById: publicProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return getRoomById(input);
      }),
    create: protectedProcedure
      .input(z.object({
        roomNumber: z.string(),
        capacity: z.number().optional(),
        floor: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return createRoom(input);
      }),
    updateStatus: protectedProcedure
      .input(z.object({
        roomId: z.number(),
        status: z.enum(["available", "occupied", "cleaning", "reserved"]),
      }))
      .mutation(async ({ input, ctx }) => {
        const room = await getRoomById(input.roomId);
        if (!room) throw new Error("Room not found");
        await updateRoomStatus(input.roomId, input.status);
        await createActivityLogEntry({
          roomId: input.roomId,
          userId: ctx.user.id,
          action: "status_change",
          previousStatus: room.status,
          newStatus: input.status,
        });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.number())
      .mutation(async ({ input }) => {
        await deleteRoom(input);
        return { success: true };
      }),
    statistics: publicProcedure.query(async () => {
      return getRoomStatistics();
    }),
  }),

  guests: router({
    getByRoom: publicProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return getGuestsByRoom(input);
      }),
    create: protectedProcedure
      .input(z.object({
        roomId: z.number(),
        name: z.string(),
        email: z.string().optional(),
        phone: z.string().optional(),
        guestCount: z.number().optional(),
        extraBed: z.number().optional(),
        checkInDate: z.date().optional(),
        checkOutDate: z.date().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const guest = await createGuest({
          ...input,
          checkInDate: input.checkInDate || new Date(),
        });
        await updateRoomStatus(input.roomId, "occupied");
        await createActivityLogEntry({
          roomId: input.roomId,
          guestId: guest.id,
          userId: ctx.user.id,
          action: "check_in",
          newStatus: "occupied",
          previousStatus: "available",
        });
        return guest;
      }),
    checkout: protectedProcedure
      .input(z.object({
        guestId: z.number(),
        roomId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        await checkOutGuest(input.guestId);
        await updateRoomStatus(input.roomId, "cleaning");
        await createActivityLogEntry({
          roomId: input.roomId,
          guestId: input.guestId,
          userId: ctx.user.id,
          action: "check_out",
          newStatus: "cleaning",
          previousStatus: "occupied",
        });
        return { success: true };
      }),
  }),

  activityLog: router({
    list: publicProcedure
      .input(z.number().optional())
      .query(async ({ input }) => {
        return getActivityLog(input || 50);
      }),
  }),

  notifications: router({
    list: publicProcedure.query(async () => {
      return getUnreadNotifications();
    }),
    markAsRead: protectedProcedure
      .input(z.number())
      .mutation(async ({ input }) => {
        await markNotificationAsRead(input);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
